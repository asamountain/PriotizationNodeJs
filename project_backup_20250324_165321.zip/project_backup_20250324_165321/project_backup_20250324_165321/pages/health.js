import { useState, useEffect } from 'react';
import dbConnect from '../lib/mongodb';
import Task from '../models/Task';

// This is a server-side function in Next.js
export async function getServerSideProps() {
  try {
    await dbConnect();
    
    // Count total tasks
    const count = await Task.countDocuments();
    
    // Get a few sample tasks
    const tasks = await Task.find().limit(3).lean();
    
    // Convert MongoDB documents to regular objects and handle ObjectId serialization
    const serializedTasks = tasks.map(task => ({
      ...task,
      _id: task._id.toString(),
      createdAt: task.createdAt ? task.createdAt.toISOString() : null,
      updatedAt: task.updatedAt ? task.updatedAt.toISOString() : null,
    }));
    
    return {
      props: {
        connected: true,
        count,
        sampleTasks: serializedTasks,
      }
    };
  } catch (error) {
    console.error('MongoDB connection error:', error);
    return {
      props: {
        connected: false,
        error: error.message,
      }
    };
  }
}

export default function HealthCheck({ connected, count, sampleTasks, error }) {
  return (
    <div style={{ padding: '20px', fontFamily: 'system-ui, sans-serif' }}>
      <h1>Application Health Check</h1>
      
      <div style={{ 
        background: connected ? '#e8f5e9' : '#ffebee',
        padding: '15px',
        borderRadius: '4px',
        marginBottom: '20px' 
      }}>
        <h2 style={{ margin: '0 0 10px 0' }}>MongoDB Status</h2>
        
        {connected ? (
          <p style={{ color: '#2e7d32', fontWeight: 'bold' }}>
            ✅ Connected to MongoDB
          </p>
        ) : (
          <p style={{ color: '#c62828', fontWeight: 'bold' }}>
            ❌ MongoDB Connection Failed: {error}
          </p>
        )}
      </div>
      
      {connected && (
        <>
          <div style={{ marginBottom: '20px' }}>
            <h2>Database Statistics</h2>
            <p>Total Tasks: <strong>{count}</strong></p>
          </div>
          
          <div>
            <h2>Sample Data from MongoDB</h2>
            {sampleTasks.length > 0 ? (
              <pre style={{ 
                background: '#f5f5f5', 
                padding: '15px', 
                borderRadius: '4px',
                overflow: 'auto'
              }}>
                {JSON.stringify(sampleTasks, null, 2)}
              </pre>
            ) : (
              <p>No tasks found in MongoDB.</p>
            )}
          </div>
        </>
      )}
    </div>
  );
} 